//类
class Person{
  private readonly id: number=5;

  constructor(){
    this.id=12;
  }
}
