<template lang="html">
  <div style="margin:20px auto 0; width:90%">
    <form class="form-horizontal" action="index.html" method="post">
      <div class="form-group">
        <label for="email" class="col-xs-3 control-label">邮箱</label>
        <div class="col-xs-9">
          <input type="email" class="form-control" name="email" id="email" placeholder="输入邮箱">
        </div>
      </div>
      <div class="form-group">
        <label for="pass" class="col-xs-3 control-label">密码</label>
        <div class="col-xs-9">
          <input type="password" class="form-control" name="pass" id="pass" placeholder="输入密码">
        </div>
      </div>
      <div class="form-group">
        <div class="">
          <button type="submit" class="btn btn-default btn-block">注册</button>
        </div>
      </div>
    </form>
  </div>
</template>

<script>
export default {
}
</script>

<style lang="css">
</style>
