let store=new Vuex.Store({
  state: {

  },
  mutation,
})

export default store
