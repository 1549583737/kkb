const http=require('http');

http.createServer((req, res)=>{
  res.write('aasdfasddfastrstawere4r');
  res.end();
}).listen(8081);
