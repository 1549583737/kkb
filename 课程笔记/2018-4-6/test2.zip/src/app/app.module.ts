import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpModule} from '@angular/http';

import { AppComponent } from './app.component';
import {HeaderComponent} from './header.component';
import {QuestionListComponent} from './question/list.component';
import {SideBarComponent} from './question/side_bar.component';
import {TopStoryComponent} from './question/topstory.component';
import {BtnGroupComponent} from './question/btn_group.component';
import {TopStoryItemComponent} from './question/topstory_item.component';
import {LinksComponent} from './question/links.component';
import {PanelComponent} from './question/panel.component';
import {FootComponent} from './question/foot.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    QuestionListComponent,
    SideBarComponent,
    TopStoryComponent,
    BtnGroupComponent,
    TopStoryItemComponent,
    LinksComponent,
    PanelComponent,
    FootComponent
  ],
  imports: [
    BrowserModule,
    HttpModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
