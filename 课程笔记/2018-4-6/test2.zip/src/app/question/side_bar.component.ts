import {Component} from '@angular/core';

@Component({
  selector: 'side-bar',
  templateUrl: './side_bar.component.html'
})

export class SideBarComponent{

}
