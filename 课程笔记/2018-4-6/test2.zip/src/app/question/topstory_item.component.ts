import {Component} from '@angular/core';

@Component({
  selector: 'topstory-item',
  templateUrl: './topstory_item.component.html'
})

export class TopStoryItemComponent{
  private showContent=false;
  private list=[];
  /*private data={
  	"question_ID": "35005530",
  	"url": "https://www.zhihu.com/question/35005530",
  	"title": "请问做H5页面需要学什么？",
  	"score": "2636.71919",
  	"bestAnswer": {
  		"answer_ID": "81511568",
  		"url": "https://www.zhihu.com/question/35005530/answer/81511568",
  		"up_count": 2291,
  		"author": "David",
  		"certified": "",
  		//"bio": "H5资森玩家",
  		"summary": "从个人最近的研究观察和私人接单的情况看来，H5页面设计已经不仅限于微信广告，其实H5现在替代的是整个移动端用户前端交互的“界面”和载体，除了广告，可能还有各种minisite，活动落地页，内容轻博客，游戏等等，某种程度上替代了原生App的部分功能和应用…",
  		"content": "从个人最近的研究观察和私人接单的情况看来，H5页面设计已经不仅限于微信广告，其实H5现在替代的是整个移动端用户前端交互的“界面”和载体，除了广告，可能还有各种minisite，活动落地页，内容轻博客，游戏等等，某种程度上替代了原生App的部分功能和应用cvxbxvcncgvncnhvbnvbnmvbnm"
  	},
  	"question_title": "请问做H5页面需要学什么？",
  	"question_content": "不是用MAKA、初页那些模板直接替换，而是能用一些类似于互动大师的工具，做出动画效果比较独特的H5页面。我本身不是这个专业的，但是由于在工作中经常跟做H5的人撕。。有的效果明明我在其他H5里面见到过，他们还是说做不了，忽悠我，说我不是专业的不懂，最后给我一个像屎一样的H5，我还得捏着鼻子给他们钱，所以我决定去学，然后糊他们一脸。"
  };*/

  private data;

  constructor(){
    console.log(this);
  }

  fnShowContent(){
    this.showContent=true;
  }

  humanNumber(count){
    if(count<1000){
      return count;
    }else if(count<1000*1000){
      return `${(count/1000).toFixed(1)}K`
    }else{
      return `${(count/(1000*1000)).toFixed(1)}M`
    }
  }
}
