import {Component} from '@angular/core';

@Component({
  selector: 'panel',
  templateUrl: './panel.component.html'
})

export class PanelComponent{
  n=1111;
}
