import {Component} from '@angular/core';

@Component({
  selector: 'foot',
  templateUrl: './foot.component.html'
})

export class FootComponent{
}
