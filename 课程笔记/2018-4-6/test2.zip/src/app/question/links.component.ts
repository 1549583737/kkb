import {Component} from '@angular/core';

@Component({
  selector: 'links',
  templateUrl: './links.component.html'
})

export class LinksComponent{
  n=1111;
}
