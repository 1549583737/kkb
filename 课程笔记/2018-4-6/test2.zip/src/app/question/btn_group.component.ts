import {Component} from '@angular/core';

@Component({
  selector: 'btn-group',
  templateUrl: './btn_group.component.html'
})

export class BtnGroupComponent{
  n=1111;
}
