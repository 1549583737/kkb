import {Component} from '@angular/core';

@Component({
  selector: 'question-list',
  templateUrl: './list.component.html'
})

export class QuestionListComponent{
  n=1111;
}
