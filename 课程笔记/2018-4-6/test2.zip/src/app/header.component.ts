import {Component} from '@angular/core';

//meta数据
@Component({
  selector: 'my-page-header',
  templateUrl: './header.component.html'
})

export class HeaderComponent{
}
