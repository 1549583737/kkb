<template lang="html">
  <div class="index-AcI9j" style="height: 1252px;">
    <section class="overview-1l9Fd">
      <div class="overview-1B6sE">
      <strong class="overview-kSMyE">4.8</strong>
      <p class="overview-1SY0_">综合评价</p>
      <p class="overview-1rZNb">高于周边商家55.0%</p>
     </div>
     <div class="overview-__cAg">
       <div class="overview-3hlIX">
         <span>服务态度</span>
         <span class="overview-3LAY5">
          <div class="Rating-wrapper_TYbDrku_0">
           <div class="Rating-gray_1kpffd5_0">
            <svg>
             <use xlink:href="#star-gray.cc081b9"></use>
            </svg>
           </div>
           <div class="Rating-actived_GBtiHkB_0" style="width: 100%;">
            <svg>
             <use xlink:href="#star-actived.d4c54d1"></use>
            </svg>
           </div>
          </div><span class="overview-qiEAZ">5.0</span></span>
        </div>
        <div class="overview-3hlIX">
       <span>菜品评价</span>
       <span class="overview-3LAY5">
        <div class="Rating-wrapper_TYbDrku_0">
         <div class="Rating-gray_1kpffd5_0">
          <svg>
           <use xlink:href="#star-gray.cc081b9"></use>
          </svg>
         </div>
         <div class="Rating-actived_GBtiHkB_0" style="width: 87.3842%;">
          <svg>
           <use xlink:href="#star-actived.d4c54d1"></use>
          </svg>
         </div>
        </div><span class="overview-qiEAZ">4.4</span></span>
      </div>
      <div class="overview-3hlIX">
       <span>送达时间</span>
       <span class="overview-3LAY5"> 39分钟 </span>
      </div>
     </div>
    </section>
    <section class="index-1g1Lf">
      <div class="index-2Rigr">
      <ul>
       <li class="rating-tags-WjcH0 rating-tags-ij9uM"> 全部(656) </li>
       <li class="rating-tags-WjcH0"> 满意(651) </li>
       <li class="rating-tags-WjcH0 rating-tags-3HD7u"> 不满意(5) </li>
       <li class="rating-tags-WjcH0"> 有图(26) </li>
      </ul>
     </div>
     <ul infinite-scroll-distance="20">
       <li class="index-RD5RX">
       <div class="comment-block-Mh_9k">
        <img class="comment-block-2pM7h" src="img/d0b0f2fc83f3ac3e4a0cfae891256png.png" />
        <div class="comment-block-3ul4F">
         <div class="comment-block-hOaYf">
          <h3 class="comment-block-2u8__">菜***子</h3>
          <small class="comment-block-2lqfX">2018-03-09</small>
         </div>
         <div>
          <div class="Rating-wrapper_TYbDrku_0">
           <div class="Rating-gray_1kpffd5_0">
            <svg>
             <use xlink:href="#star-gray.cc081b9"></use>
            </svg>
           </div>
           <div class="Rating-actived_GBtiHkB_0" style="width: 100%;">
            <svg>
             <use xlink:href="#star-actived.d4c54d1"></use>
            </svg>
           </div>
          </div>
          <span class="comment-block-rYfog">30分钟送达</span>
         </div>
         <!---->
         <!---->
         <!---->
         <div>
          <ul class="comment-block-3fd0V">
           <li>南瓜粥+韭菜盒子+蒸饺+萝卜干</li>
           <li>茶叶蛋</li>
           <li>黑米糕</li>
          </ul>
         </div>
        </div>
       </div></li>
     </ul>
    </section>
  </div>
</template>

<script>
export default {
}
</script>

<style lang="css">
</style>
