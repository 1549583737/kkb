<template lang="html">
  <div data-v-55b29b2f="" class="shop-info" style="height: 1252px;">
    <section data-v-55b29b2f="" class="section">
     <h3 class="section-title">配送信息</h3>
     <div class="delivery-36amC">
      <div>
       <!---->
       <span>由蜂鸟快送提供配送，约31分钟送达，距离2.1km</span>
      </div>
      <!---->
      <div>
       配送费￥2.5
      </div>
     </div>
    </section>
    <section data-v-55b29b2f="" class="section">
     <h3 class="section-title">活动与服务</h3>
     <div class="activity-2iOA8">
      <div class="activity-1hPHa activity-25cwN">
       <span class="mini-tag-1Lyw4 activity-N5WvH" style="background-color: rgb(112, 188, 70);">首单<span class="activity-yP-9y mini-tag-1ezSQ">首单</span></span>
       <span class="activity-3dUjU">新用户下单立减17元(不与其它活动同享)</span>
      </div>
      <div class="activity-1hPHa activity-25cwN">
       <span class="mini-tag-1Lyw4 activity-N5WvH" style="background-color: rgb(240, 115, 115);">满减<span class="activity-yP-9y mini-tag-1ezSQ">满减</span></span>
       <span class="activity-3dUjU">满25减15，满49减17，满79减20</span>
      </div>
      <div class="activity-1hPHa activity-25cwN">
       <span class="mini-tag-1Lyw4 activity-N5WvH" style="background-color: rgb(240, 115, 115);">折扣<span class="activity-yP-9y mini-tag-1ezSQ">折扣</span></span>
       <span class="activity-3dUjU">3.6折暖胃清火白粥</span>
      </div>
      <div class="activity-1hPHa activity-25cwN">
       <span class="mini-tag-1Lyw4 activity-N5WvH" style="background-color: rgb(240, 115, 115);">折扣<span class="activity-yP-9y mini-tag-1ezSQ">折扣</span></span>
       <span class="activity-3dUjU">5.3折钜惠精致套餐</span>
      </div>
      <div class="activity-1hPHa activity-25cwN">
       <span class="mini-tag-1Lyw4 activity-N5WvH" style="background-color: rgb(60, 199, 145);">满赠<span class="activity-yP-9y mini-tag-1ezSQ">满赠</span></span>
       <span class="activity-3dUjU">满59元赠送小菜1份</span>
      </div>
      <div class="activity-1hPHa activity-25cwN">
       <span class="mini-tag-1Lyw4 activity-N5WvH" style="background-color: rgb(255, 114, 57);">返券<span class="activity-yP-9y mini-tag-1ezSQ">返券</span></span>
       <span class="activity-3dUjU">下单可返3元代金券</span>
      </div>
      <div class="activity-1hPHa activity-25cwN">
       <span class="mini-tag-1Lyw4 activity-N5WvH" style="border: 1px solid rgb(153, 153, 153); color: rgb(153, 153, 153);">票<span class="activity-yP-9y mini-tag-1ezSQ">票</span></span>
       <span class="activity-3dUjU">该商家支持开发票，开票订单金额100元起，请在下单时填写好发票抬头</span>
      </div>
     </div>
    </section>
    <section data-v-55b29b2f="" class="section album-1cjk_">
     <h3 class="section-title">商家实景</h3>
     <div class="album-1pGkG">
      <a href="javascript:"><img src="img/5cbf7189df51aa02b9e379ac7b43cjpeg.jpeg" /><span class="album-2vPHW">门面(1张)</span></a>
      <a href="javascript:"><img src="img/123fc50c5519524601dc2cf7bfc81jpeg.jpeg" /><span class="album-2vPHW">大堂(1张)</span></a>
     </div>
    </section>
    <div data-v-55b29b2f="">
     <section class="section">
      <h3 class="section-title">商家信息</h3>
      <ul class="detail-1_W84">
       <li>因爱而生，专注做粥，只为给你更好的，我们一直在用心！</li>
       <li><span>品类</span><span>包子粥店, 简餐</span></li>
       <li><span>商家电话</span><span><span>13356003920</span>
         <svg class="arrow-right">
          <use xlink:href="#arrow-right"></use>
         </svg></span></li>
       <li><span>地址</span><span>浙江省嘉兴市兴业街店面23号</span></li>
       <li><span>营业时间</span><span>07:30-21:30</span></li>
      </ul>
     </section>
     <section class="section">
      <a href="https://h5.ele.me/shop/certification/#/?restaurant_id=1352564764536131" class="section-title detail-1wFyo">营业资质
       <svg class="arrow-right">
        <use xlink:href="#arrow-right"></use>
       </svg></a>
     </section>
    </div>
  </div>
</template>

<script>
export default {
}
</script>

<style lang="css">
</style>
