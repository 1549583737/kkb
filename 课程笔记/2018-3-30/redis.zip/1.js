const redis=require('redis');

let client=redis.createClient({host: 'localhost', port: 6379, password: '123456'});

/*client.get('a', (err, data)=>{
  if(err){
    console.log('获取失败');
  }else{
    console.log(data);
  }
});*/

client.set('a', 55, (err, msg)=>{
  if(err){
    console.log('设置失败');
  }else{
    console.log('成功', msg);
  }

  client.quit();
});
